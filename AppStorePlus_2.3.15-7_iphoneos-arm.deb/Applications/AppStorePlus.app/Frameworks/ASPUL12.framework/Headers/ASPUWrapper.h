#ifndef ASPUWrapper_h
#define ASPUWrapper_h

#include <stdint.h>

#if __cplusplus
extern "C" {
#endif

typedef enum {
    ASPUEventInitialized = 1,
    ASPUEventInitializationFailed,
    ASPUEventRewardedLoaded,
    ASPUEventRewardedLoadFailed,
    ASPUEventRewardedDisplayed,
    ASPUEventRewardedDisplayFailed,
    ASPUEventRewardedEarned,
    ASPUEventRewardedClosed
} ASPUEvent;

typedef void (*ASPUEventCallback)(int32_t event, const char *message);

__attribute__((visibility("default"))) int32_t ASPUABIVersion(void);
__attribute__((visibility("default"))) void ASPUConfigure(
    const char *appKey,
    const char *rewardedAdUnitID,
    const char *userID,
    ASPUEventCallback callback);
__attribute__((visibility("default"))) void ASPULoadRewarded(void);
__attribute__((visibility("default"))) int32_t ASPURewardedReady(void);
__attribute__((visibility("default"))) void ASPUShowRewarded(
    void *viewController,
    const char *placementName);

#if __cplusplus
}
#endif

#endif
